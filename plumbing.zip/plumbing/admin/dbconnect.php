<?php


	error_reporting( ~E_DEPRECATED & ~E_NOTICE );

	
	$host = "localhost";
    $user = "id9013853_umair";
    $pass = "123456";
    $databaseName = "id9013853_plumbing1";
    

    $conn = mysqli_connect($host, $user, $pass, $databaseName);

	if ( !$conn ) {
		die("Connection failed : " . mysqli_error());
	}