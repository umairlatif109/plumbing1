<?php
$servername = "localhost";
$username = "id9013853_umair";
$password = "123456";
$dbname = "id9013853_plumbing1";

// Create connection

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



?>
